package com.anfeng.wuhao.anfengkuaikan.task;

public interface Task<T> {
	void run(T t);
}
