package com.anfeng.wuhao.anfengkuaikan.bean;

import java.io.Serializable;

/**
 * ============================
 * 作者： 吴浩
 * 时间： 2017/5/12.
 * 描述： 所以实体的基类
 * =============================
 */

public abstract class Entity implements Serializable{

}
